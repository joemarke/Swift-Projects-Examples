//
//  Crisis_AvertedApp.swift
//  Crisis Averted
//
//  Created by Joe Marke on 17/03/2021.
//

import SwiftUI

@main
struct Crisis_AvertedApp: App {
    @AppStorage("isDarkMode") private var isDarkMode = false
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(isDarkMode ? .dark : .light)
        }
    }
}

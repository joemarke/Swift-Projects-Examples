//
//  ContentView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 17/03/2021.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            ResourcesView()
                .tabItem {
                    Image(systemName: "phone")
                    Text("Resources")
                }
            
            RightsView()
                .tabItem {
                    Image(systemName: "person.fill.questionmark")
                    Text("My Rights")
                }
            
            HelpOutView()
                .tabItem {
                    Image(systemName: "hand.thumbsup")
                    Text("Help Out")
                }
        }
        .accentColor(Color("PrimaryColour"))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.light)
    }
}

//
//  HelpOutView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 30/03/2021.
//

import SwiftUI

struct HelpOutView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                Text("How you can help")
                    .font(.system(size: 32, weight: .bold, design: .default))
                    .multilineTextAlignment(.center)
                    .padding()
                Text("Use the following resources to locate useful community help centres. If you wish to help out, you can offer to volunteer or donate to them.")
                    .font(.system(size: 16, weight: .medium, design: .default))
                    .padding(.horizontal, 24)
                
                HStack {
                    Spacer()
                    NavigationLink(destination: HelpOutAbuseSheltersView()) {
                        HelpOutButton(buttonText: "Abuse shelters", buttonSubtext: "5 found near you")
                    }
                    Spacer()
                    NavigationLink(destination: HelpOutBloodDonationsView()) {
                        HelpOutButton(buttonText: "Blood donations", buttonSubtext: "1 found near you")
                    }
                    Spacer()
                }
                HStack {
                    Spacer()
                    NavigationLink(destination: HelpOutCharityShopsView()) {
                        HelpOutButton(buttonText: "Charity shops", buttonSubtext: "12 found near you")
                    }
                    Spacer()
                    NavigationLink(destination: HelpOutFoodBanksView()) {
                        HelpOutButton(buttonText: "Food banks", buttonSubtext: "7 found near you")
                    }
                    Spacer()
                }
                HStack {
                    Spacer()
                    NavigationLink(destination: HelpOutHomelessSheltersView()) {
                        HelpOutButton(buttonText: "Homeless shelters", buttonSubtext: "5 found near you")
                    }
                    Spacer()
                    NavigationLink(destination: HelpOutMentalHealthAidView()) {
                        HelpOutButton(buttonText: "Mental health aid", buttonSubtext: "8 found near you")
                    }
                    Spacer()
                }
                
                Text("Please note: the following resources are currently only showing places in the Newcastle upon Tyne region. Future development will expand to other areas of the UK.")
                    .font(.system(size: 16, weight: .light, design: .default))
                    .italic()
                    .padding(24)
            }
            .navigationTitle("Crisis Averted")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading){
                    NavigationLink(destination: SettingsView()) {
                        Image(systemName: "gear")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: InformationView()) {
                        Image(systemName: "info.circle")
                    }
                }
            }
        }
    }
}

struct HelpOutView_Previews: PreviewProvider {
    static var previews: some View {
        HelpOutView()
    }
}

struct HelpOutButton: View {
    var buttonText: String
    var buttonSubtext: String
    
    var body: some View{
        VStack(alignment: .leading){
            HStack {
                Text(buttonText)
                    .font(.system(size: 17, weight: .bold, design: .default))
                    .padding(.horizontal, 8)
                Spacer()
            }
            HStack {
                Text(buttonSubtext)
                    .font(.system(size: 14, weight: .medium, design: .default))
                    .padding(.horizontal, 8)
                Spacer()
            }
        }
        .frame(width: 175, height: 68)
        .foregroundColor(.white)
        .background(LinearGradient(gradient: Gradient(colors: [Color("PrimaryColour"), Color("GradientSecondary")]), startPoint: .topLeading, endPoint: .bottomTrailing))
        .cornerRadius(8)
        .padding(4)
    }
}


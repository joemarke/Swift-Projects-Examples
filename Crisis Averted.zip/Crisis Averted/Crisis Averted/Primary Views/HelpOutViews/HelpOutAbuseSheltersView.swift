//
//  HelpOutAbuseSheltersView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 25/04/2021.
//

import SwiftUI

struct HelpOutAbuseSheltersView: View {
    var body: some View {
        VStack {
            SubheadingText(titleText: "Abuse Shelters")
                .multilineTextAlignment(.center)
            List {
                Link("Newcastle Women's Aid (Byker)", destination: URL(string: "maps://?address=1+Dunstanburgh+Rd,+Newcastle+upon+Tyne+NE6+2PT")!)
                Link("Newcastle Women's Aid (City Centre)", destination: URL(string: "maps://?address=Mea+House,+Third+Ave,+Newcastle+upon+Tyne+NE1+8XS")!)
                Link("Newcastle Women's Aid (High Heaton)", destination: URL(string: "maps://?address=Newcastle+upon+Tyne+NE6+1HZ")!)
                Link("Oasis Community Housing", destination: URL(string: "maps://?address=7+Delta+Bank+Road,+Metro+Riverside+Park,+Gateshead+NE11+9DJ")!)
                Link("Shelter North East", destination: URL(string: "maps://?address=140+Pilgrim+St,+Newcastle+upon+Tyne+NE1+6TH")!)
            }
            
            VStack(spacing: 0) {
                Text("Any shelters missing from this list?")
                Link("Contact us.", destination: URL(string: "mailto:joe.ik.marke@gmail.com")!)
            }
            
            Spacer()
        }
    }
}

struct HelpOutAbuseSheltersView_Previews: PreviewProvider {
    static var previews: some View {
        HelpOutAbuseSheltersView()
    }
}

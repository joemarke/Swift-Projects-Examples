//
//  HelpOutBloodDonationsView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 25/04/2021.
//

import SwiftUI

struct HelpOutBloodDonationsView: View {
    var body: some View {
        VStack {
            SubheadingText(titleText: "Blood Donation Centres")
                .multilineTextAlignment(.center)
            List {
                Link("NHSBT Newcastle Blood Donor Centre", destination: URL(string: "maps://?address=Holland+Drive,+Newcastle+upon+Tyne+NE2+4NQ")!)
            }
            
            VStack(spacing: 0) {
                Text("Any blood donation centres missing from this list?")
                Link("Contact us.", destination: URL(string: "mailto:joe.ik.marke@gmail.com")!)
            }
            
            Spacer()
        }
    }
}

struct HelpOutBloodDonationsView_Previews: PreviewProvider {
    static var previews: some View {
        HelpOutBloodDonationsView()
    }
}

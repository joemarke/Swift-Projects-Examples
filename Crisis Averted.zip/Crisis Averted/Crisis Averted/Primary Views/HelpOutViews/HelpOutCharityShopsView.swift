//
//  HelpOutCharityShopsView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct HelpOutCharityShopsView: View {
    var body: some View {
        VStack {
            SubheadingText(titleText: "Charity Shops")
                .multilineTextAlignment(.center)
            List {
                Link("Age UK", destination: URL(string: "maps://?address=167,+Grainger+Market,+117+Grainger+St,+City+Centre,+Newcastle+upon+Tyne+NE1+5AE")!)
                Group {
                    Link("British Heart Foundation (Clayton St)", destination: URL(string: "maps://?address=69+Clayton+St,+Newcastle+upon+Tyne+NE1+5PY")!)
                    Link("British Heart Foundation (Eldon Square)", destination: URL(string: "maps://?address=14c+Clayton+St,+Newcastle+upon+Tyne+NE1+5PU")!)
                }
                Link("British Red Cross Shop", destination: URL(string: "maps://?address=17-19+Nun+St,+Newcastle+upon+Tyne+NE1+5AG")!)
                Link("Cancer Research UK", destination: URL(string: "maps://?address=61+Grainger+St,+Newcastle+upon+Tyne+NE1+5JE")!)
                Group {
                    Link("Marie Curie Charity Shop (Byker)", destination: URL(string: "maps://?address=44+Shields+Rd,+Byker,+Newcastle+upon+Tyne+NE6+1DR")!)
                    Link("Marie Curie Charity Shop (Grainger St)", destination: URL(string: "maps://?address=55+Grainger+St,+Newcastle+upon+Tyne+NE1+5JE")!)
                }
                Link("Oxfam", destination: URL(string: "maps://?address=99+Percy+St,+Newcastle+upon+Tyne+NE1+7RT")!)
                Link("PDSA Charity Shop", destination: URL(string: "maps://?address=52+Clayton+St,+Newcastle+upon+Tyne+NE1+5PF")!)
                Group {
                    Link("St Oswald's Hospice Charity Shop (Jesmond)", destination: URL(string: "maps://?address=5+Hazelwood+Ave,+Jesmond,+Newcastle+upon+Tyne+NE2+3HU")!)
                    Link("St Oswald's Hospice Charity Shop (Byker)", destination: URL(string: "maps://?address=175-181+Shields+Rd,+Newcastle+upon+Tyne+NE6+1DP")!)
                }
                Link("The Salvation Army Charity Shop", destination: URL(string: "maps://?address=70+Clayton+St,+Newcastle+upon+Tyne+NE1+5PG")!)
            }
            
            VStack(spacing: 0) {
                Text("Any charity shops missing from this list?")
                Link("Contact us.", destination: URL(string: "mailto:joe.ik.marke@gmail.com")!)
            }
            
            Spacer()
        }
    }
}

struct HelpOutCharityShopsView_Previews: PreviewProvider {
    static var previews: some View {
        HelpOutCharityShopsView()
    }
}

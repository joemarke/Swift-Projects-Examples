//
//  FoodBanksView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 19/04/2021.
//

import SwiftUI

struct HelpOutFoodBanksView: View {
    var body: some View {
        VStack {
            SubheadingText(titleText: "Food Banks")
                .multilineTextAlignment(.center)
            List {
                Link("Connect25 Food Bank", destination: URL(string: "maps://?address=162+Brinkburn+St,+Byker,+Newcastle+upon+Tyne+NE6+2AR")!)
                Link("FoodCycle Newcastle Westgate", destination: URL(string: "maps://?address=Newcastle+upon+Tyne+NE4+6QD")!)
                Link("Gateshead Foodbank", destination: URL(string: "maps://?address=The+Davidson+Building,+Gateshead+Hwy,+Gateshead+NE8+1BG")!)
                Link("Newcastle West End Foodbank", destination: URL(string: "maps://?address=Benwell+Ln,+Newcastle+upon+Tyne+NE15+6LX")!)
                Link("People's Kitchen", destination: URL(string: "maps://?address=56+Bath+Ln,+Newcastle+upon+Tyne+NE4+5SQ")!)
                Link("The Trussell Trust Food Bank (Heaton)", destination: URL(string: "maps://?address=45+Heaton+Rd,+Newcastle+upon+Tyne+NE6+1SB")!)
                Link("The Trussell Trust Food Bank (West Rd)", destination: URL(string: "maps://?address=West+Rd,+Newcastle+upon+Tyne+NE4+8AQ")!)
            }
            
            VStack(spacing: 0) {
                Text("Any food banks missing from this list?")
                Link("Contact us.", destination: URL(string: "mailto:joe.ik.marke@gmail.com")!)
            }
            
            Spacer()
        }
    }
}

struct FoodBanksView_Previews: PreviewProvider {
    static var previews: some View {
        HelpOutFoodBanksView()
    }
}

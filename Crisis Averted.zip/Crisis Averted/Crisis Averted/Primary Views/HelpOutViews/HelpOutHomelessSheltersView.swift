//
//  HelpOutHomelessSheltersView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct HelpOutHomelessSheltersView: View {
    var body: some View {
        VStack {
            SubheadingText(titleText: "Homeless Shelters")
                .multilineTextAlignment(.center)
            List {
                Link("Crisis Skylight Newcastle", destination: URL(string: "maps://?address=City+House,+1+City+Rd,+Newcastle+upon+Tyne+NE1+2AF")!)
                Link("Francis House", destination: URL(string: "maps://?address=202+Westgate+Rd,+Newcastle+upon+Tyne+NE4+6AN")!)
                Link("Jemond House YWCA", destination: URL(string: "maps://?address=Clayton+Rd,+Jesmond,+Newcastle+upon+Tyne+NE2+1UJ")!)
                Link("Oasis Community Housing", destination: URL(string: "maps://?address=7+Delta+Bank+Road,+Metro+Riverside+Park,+Gateshead+NE11+9DJ")!)
                Link("Shelter North East", destination: URL(string: "maps://?address=150+Pilgrim+St,+Newcastle+upon+Tyne+NE1+6TH")!)
            }
            
            VStack(spacing: 0) {
                Text("Any shelters missing from this list?")
                Link("Contact us.", destination: URL(string: "mailto:joe.ik.marke@gmail.com")!)
            }
            
            Spacer()
        }
    }
}

struct HelpOutHomelessSheltersView_Previews: PreviewProvider {
    static var previews: some View {
        HelpOutHomelessSheltersView()
    }
}

//
//  HelpOutMentalHealthAidView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 25/04/2021.
//

import SwiftUI

struct HelpOutMentalHealthAidView: View {
    var body: some View {
        VStack {
            SubheadingText(titleText: "Mental Health Aid")
                .multilineTextAlignment(.center)
            List {
                Link("Balance", destination: URL(string: "maps://?address=42+Bourne+Ave,+Newcastle+upon+Tyne+NE4+9XN")!)
                Link("Be. Wellbeing", destination: URL(string: "maps://?address=Mea+House,+Ellison+Pl,+Newcastle+upon+Tyne+NE1+8XS")!)
                Link("Chilli Studios", destination: URL(string: "maps://?address=Blackfriars+Hall,+New+Bridge+St,+Newcastle+upon+Tyne+NE1+2TQ")!)
                Link("Glister Counselling", destination: URL(string: "maps://?address=130+Moorside+N,+Newcastle+upon+Tyne+NE4+9DY")!)
                Link("Jesmond Therapy Centre", destination: URL(string: "maps://?address=7+Holly+Ave+W,+Jesmond,+Newcastle+upon+Tyne+NE2+2AR")!)
                Link("Myndr", destination: URL(string: "maps://?address=Tus+Park,+27+Grainger+St,+Newcastle+upon+Tyne+NE1+5JE")!)
                Link("Newcastle West Community Treatment Team", destination: URL(string: "maps://?address=Silverdale,+8RR,+Grainger+Park+Rd,+Newcastle+upon+Tyne")!)
                Link("Our Mind's Work", destination: URL(string: "maps://?address=166+Brinkburn+St,+Byker,+Newcastle+upon+Tyne+NE6+2AR")!)
                
            }
            
            VStack(spacing: 0) {
                Text("Any mental health aid centres missing from this list?")
                Link("Contact us.", destination: URL(string: "mailto:joe.ik.marke@gmail.com")!)
            }
            
            Spacer()
        }
    }
}

struct HelpOutMentalHealthAidView_Previews: PreviewProvider {
    static var previews: some View {
        HelpOutMentalHealthAidView()
    }
}

//
//  ResourcesAbandonedVehicleView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct ResourcesAbandonedVehicleView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Abandoned or Illegally\nParked Vehicle")
                .multilineTextAlignment(.center)
            
            VStack {
                ResourcesAdviceText(adviceText: "If the vehicle is causing a real problem, try contacting the owner first - if unsuccesful, contact your local council.",
                                    secondaryText: "Ask yourself firstly, is this vehicle actually creating a dangerous situation? If it is not, does any further action need to be taken? If the vehicle could potentially cause dangerous issues, attempt to contact the owner - a good way to do this is to leave a (waterproof, if possible) note on the windshield, informing them of the issues of their vehicle placement. They may be simply unaware of the problems they are causing.\n\nIf nothing comes of that, report it to your local council, who will likely remove it. They will not get involved if the car is on private property, however.",
                                    bottomPadding: 18
                )
            }
            .frame(width: 340, height: 430, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "The police are not suited to deal with this problem; it is a job for the council instead. Bringing the police into your community can also be dangerous for certain people, particulary people from ethnic minority backgrounds and people with disabilities.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesAbandonedVehicleView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesAbandonedVehicleView()
    }
}

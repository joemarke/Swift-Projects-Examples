//
//  ResourcesAntisocialBehaviour.swift
//  Crisis Averted
//
//  Created by Joe Marke on 07/04/2021.
//

import SwiftUI

struct ResourcesAbuseAtHomeView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Abuse at home")
                .multilineTextAlignment(.center)
            
            VStack {
                ResourcesAdviceText(adviceText: "Contact help online as soon as possible.",
                                    secondaryText: "There are many resources available online that provide help. Contact any of the provided resources to get appropriate and specific help. If you decide to leave, be careful who you tell - ensure your abuser does not know where you're going.",
                                    bottomPadding: 18
                )
                
                Group {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(spacing: 0, content: {
                            Text("• For women: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Refuge", destination: URL(string: "https://www.nationaldahelpline.org.uk/en/How-can-we-support-you")!)
                            Text(", ")
                            Link("Women's Aid", destination: URL(string: "https://chat.womensaid.org.uk/")!)
                            Text(", or ")
                            Spacer()
                        })
                        
                        HStack(spacing: 0) {
                            Link("  Victim Support", destination: URL(string: "https://www.victimsupport.org.uk/help-and-support/get-help/")!)
                            Spacer()
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.bottom, 2)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 0, content: {
                            Text("• For men: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Men's adivce line", destination: URL(string: "https://mensadviceline.org.uk/")!)
                            Spacer()
                        })
                        
                        HStack(spacing: 0, content: {
                            Text("• For LGBTQ+: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Galop", destination: URL(string: "http://www.galop.org.uk/domesticabuse/")!)
                            Spacer()
                        })
                    }
                    .padding(.horizontal, 12)
                }
            }
            .frame(width: 340, height: 310, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "Involvement of the police can upset the abuser, which could be dangerous for you. There is also no guarantee the police would take the appropriate action - they are not trained to deal with abuse like the resources provided are.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesAntisocialBehaviour_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesAbuseAtHomeView()
            
    }
}

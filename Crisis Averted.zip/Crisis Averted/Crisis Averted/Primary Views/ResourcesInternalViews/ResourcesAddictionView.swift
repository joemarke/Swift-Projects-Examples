//
//  ResourcesAddictionView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct ResourcesAddictionView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Addiction")
                .multilineTextAlignment(.center)
            
            VStack {
                
                ResourcesAdviceText(adviceText: "Contact your GP to get a referral for free treatment, or find a nearby counsilling service.",
                                    secondaryText: "Your GP can provide help in many areas of recovery, such as providing medication, finding self-help groups, offering talking therapies, providing detoxification to help cope with withdrawal symptoms, and reducing harm by offering tests and treatments for problems like hepatitis or HIV.\n\nIf you are unable to see a GP, or do not wish to, you can locate local drug treatment services using the Frank website provided below. The Adfam website also provides a list of useful organisations.\n\nIf you want to help an addicted friend or relative, try to build their trust and respect their privacy without threatening them or expecting immediate change. Try to provide practical support, such as contacting the GP or attending appointments/meetings with them.\n\nUnderstand they may engage in their addiction as a way to avoid dealing with another problem, such as mental illness, or they fear the consequences of their actions, such as losing their job or going to prison. Overcoming addiction takes a great amount of willpower and determination, and can be a long process - your support is needed for the entirety of it.",
                                    bottomPadding: 18
                )
                
                Group {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(spacing: 0) {
                            Text("• Find support near you: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Frank", destination: URL(string: "https://www.talktofrank.com/get-help/find-support-near-you")!)
                            Spacer()
                        }
                        
                        HStack(spacing: 0) {
                            Text("• Useful organisations: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Adfam", destination: URL(string: "https://adfam.org.uk/help-for-families/useful-organisations")!)
                            Spacer()
                        }
                        
                            Text("• Helping someone with an addiction:")
                                .font(.system(size: 16, weight: .medium, design: .default))
                        
                        HStack(spacing: 0) {
                            Text("  ")
                            Link("Verywell Mind", destination: URL(string: "https://www.victimsupport.org.uk/help-and-support/get-help/")!)
                        }
                    }
                    .padding(.horizontal, 12)
                }
            }
            .frame(width: 340, height: 830, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "The penalties in place for taking drugs have the potential to only worsen someone's addiction. Fines, as well as a criminal record losing someone's job, are only going to further an addicted person's needs and desires for drugs. Serving time in prison can also have this same effect: securing employment once leaving prison can be extremely difficult, on top of low government financial support.\n\nIt is also important to be aware of the social construction of laws, particularly surrounding drugs - recreational cannabis is legal in 17 U.S. states, but is a Class B drug in the United Kingdom. Not everything that is illegal is necessarily morally wrong; for example, slavery was legal in the U.K. until the Abolition Act of 1807.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesAddictionView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesAddictionView()
    }
}

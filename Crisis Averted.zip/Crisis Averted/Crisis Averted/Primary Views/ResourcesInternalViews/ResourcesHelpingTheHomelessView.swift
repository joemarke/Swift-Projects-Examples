//
//  ResourcesHelpingTheHomelessView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct ResourcesHelpingTheHomelessView: View {
    
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Helping The Homeless")
                .multilineTextAlignment(.center)
            
            VStack {
                ResourcesAdviceText(adviceText: "Offer your time, attention and important items, and direct them to nearby shelters or food banks if they need it.",
                                    secondaryText: "The first way to help a homeless person is to simply greet them - a simple greeting, asking for their name and how they are doing can go a long way. Ask them what it is they need, and if you are able to, try to provide it for them.\n\nExamples of practical material items you can offer them include clothing, especially socks, and high-factor sunscreen in the summer. Offer a hot drink or some water, as well as some food if you can - checking first they do not have any allergies or intolerances. Toiletries and sanitary items, such as a mask, can be of great use, as well as a gift card to a fast-food chain or grocery store.\n\nYou can also offer to direct them to nearby shelters or food banks - remember homeless people are unlikely to have access to the internet, so may not be aware of nearby places they can get help.\n\nThe views of charities and homeless support groups vary when it comes to the topic of giving money to homeless people. It is important to remember that you should try to provide what a homeless person asks for, if you can - if money is more important to them than other products, consider offering some. Some things, for example washing their clothes at a laundrette, or staying in a hotel room, are difficult to gift to a homeless person without giving them money.\n\nIf you wish to donate your money, but are fearful of it directly fueling addiction, consider donating to local grassroots charities instead, who will use the money to tackle and prevent homelessness at its roots.",
                                    bottomPadding: 18
                )
                
                Group {
                    VStack(alignment: .leading, spacing: 0) {
                        
                        HStack(spacing: 0) {
                            Text("• How else you can help: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("The Big Issue", destination: URL(string: "https://www.bigissue.com/latest/what-to-do-if-you-see-a-homeless-person/")!)
                        }
                        
                        HStack(spacing: 0) {
                            Text("•")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link(" Homeless Link", destination: URL(string: "https://www.homeless.org.uk/how-you-can-help-someone-sleeping-rough")!)
                            Spacer()
                        }
                        
                        Text("• Check out the 'Help Out' section to find")
                            .font(.system(size: 16, weight: .medium, design: .default))
                        Text("  nearby food banks and shelters")
                            .font(.system(size: 16, weight: .medium, design: .default))
                        
                    }
                    .padding(.horizontal, 12)
                }
            }
            .frame(width: 340, height: 1040, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "Involving the police is likely to only worsen matters. The police can respond potentially dangerously, as they may not have the appropriate training to manage someone with mental health issues, or someone who is suffering from addiction. If you are worried about a homeless person's safety, try locating a nearby shelter for them, or become familiar with local organisations that are not affiliated with the police.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesHelpingTheHomelessView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesHelpingTheHomelessView()
    }
}

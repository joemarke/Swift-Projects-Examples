//
//  ResourcesLostPetView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct ResourcesLostPetView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Lost Pet")
                .multilineTextAlignment(.center)
            
            VStack {
                
                ResourcesAdviceText(adviceText: "If you have lost your pet, or found a lost pet, contact the appropriate resource listed below. Every council will have a dog warden service.",
                                    secondaryText: "There are several resources available that are used when a pet is lost or found - officially, the government recommends contacting your council's dog warden service for lost dogs.\n\nYou should try contacting local pet shelters, vets, and kennels for advice. Posts on social media can also be effective.",
                                    bottomPadding: 18
                )
                
                Group {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(spacing: 0) {
                            Text("• For lost and found pets: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Animal Search", destination: URL(string: "https://www.animalsearchuk.co.uk/")!)
                            Spacer()
                        }
                        
                        Text("• What to do if you have lost your dog:")
                            .font(.system(size: 16, weight: .medium, design: .default))
                        
                        HStack(spacing: 0) {
                            Text("  ")
                            Link("Dogs Trust", destination: URL(string: "https://www.dogstrust.org.uk/help-advice/dog-care/lost-your-dog#:~:text=Contact%20Local%20Kennels%2C%20Rehoming%20Centres%20and%20Vets&text=Contact%20the%20Kennel%20Club%20on,your%20dog%20be%20brought%20in.")!)
                        }
                        
                        Text("• Support if you have lost your cat:")
                            .font(.system(size: 16, weight: .medium, design: .default))
                        
                        HStack(spacing: 0) {
                            Text("  ")
                            Link("Cats Protection", destination: URL(string: "https://www.cats.org.uk/")!)
                        }
                    }
                    .padding(.horizontal, 12)
                }
            }
            .frame(width: 340, height: 450, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "The police will not help with lost pets - instead, they will just redirect you to the resources listed above. Bringing the police into your community for a problem they do not have the powers to solve has the potential to be damaging for certain members of the community.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            
            Spacer()
        }
    }
}

struct ResourcesLostPetView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesLostPetView()
    }
}

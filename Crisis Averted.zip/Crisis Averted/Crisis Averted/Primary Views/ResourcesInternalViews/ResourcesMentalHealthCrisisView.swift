//
//  ResourcesMentalHealthCrisisView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct ResourcesMentalHealthCrisisView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Mental Health Crisis")
                .multilineTextAlignment(.center)
            
            VStack {
                
                ResourcesAdviceText(adviceText: "Contact a specialised service, or if you or someone else requires immediate help in your location, contact a crisis team.",
                                    secondaryText: "If you, or someone you know, is experiencing a mental health crisis, you have the option of contacting a number of specialised services that can help you; this includes free 24/7 numbers to call or text, as well as online chats if that is more comfortable for you.\n\nThere are also resources available informing you on how you can better deal with a potential crisis. Contacting a GP can be a difficult step, but it may allow you to get the appropriate medication prescribed.\n\nIf you, or someone else, may attempt suicide, you can call 999 for an ambulance or go straight to A&E, even if you have not sustained any injuries. Mental health emergencies are serious - you are not wasting anybody's time. If you want to help someone in this situation, go with them if you can.",
                                    bottomPadding: 18
                )
                
                Group {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(spacing: 0) {
                            Text("• ")
                            Link("24 hour NHS helpline", destination: URL(string: "https://www.nhs.uk/service-search/mental-health/find-an-urgent-mental-health-helpline")!)
                            Spacer()
                        }
                        
                        HStack(spacing: 0) {
                            Text("• ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Samaritans", destination: URL(string: "https://www.samaritans.org/how-we-can-help/contact-samaritan/")!)
                            Text(" (call or email 24/7)")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Spacer()
                        }
                        
                        Group {
                            Text("• Text \"SHOUT\" to 85258 to contact the ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            
                            HStack(spacing: 0) {
                                Link("  Shout Crisis Text Line", destination: URL(string: "sms://85258")!)
                                Text(" (or \"YM\" if you are")
                                    .font(.system(size: 16, weight: .medium, design: .default))
                            }
                            
                            Text("  under 18")
                                .font(.system(size: 16, weight: .medium, design: .default))
                        }
                        
                        Group {
                            Text("• If you are under 19, you can contact")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            
                            Text("  Childline (the number will not appear on")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            
                            HStack(spacing: 0) {
                                Text("  your phone bill) at ")
                                    .font(.system(size: 16, weight: .medium, design: .default))
                                Link("0800 1111", destination: URL(string: "tel://08001111")!)
                            }
                        }
                        
                        HStack(spacing: 0) {
                            Text("• Helping yourself cope: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Mind", destination: URL(string: "https://www.mind.org.uk/need-urgent-help/what-can-i-do-to-help-myself-cope/")!)
                        }
                        
                        Group {
                            Text("• Helping with suicidal thoughts: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("  Staying Safe", destination: URL(string: "https://stayingsafe.net/")!)
                        }
                        
                        HStack(spacing: 0) {
                            Text("• For men in particular: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Men's Health", destination: URL(string: "www.menshealthforum.org.uk")!)
                        }
                        
                        HStack(spacing: 0) {
                            Text("• For anxiety: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Anxiety UK", destination: URL(string: "https://anxietyuk.org.uk")!)
                        }
                        
                        HStack(spacing: 0) {
                            Text("• For bipolar disorder: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Bipolar UK", destination: URL(string: "https://bipolaruk.org.uk")!)
                        }

                        HStack(spacing: 0) {
                            Text("• For OCD: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("OCD UK", destination: URL(string: "https://ocduk.org")!)
                        }
                        
                    }
                    .padding(.horizontal, 12)
                }
            }
            .frame(width: 340, height: 860, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "The police are not sufficiently trained when it comes to people having a mental health crisis - between one third to a half of all people killed by the police in the U.S. have had some kind of disability. There have even been instances of people getting killed by the police after calling them to help with their own mental health crisis.\n\nFinding community-oriented charities and safe spaces are a safer way to go, especially as they will have more specialised training.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesMentalHealthCrisisView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesMentalHealthCrisisView()
    }
}

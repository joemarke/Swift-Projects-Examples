//
//  ResourcesNoiseConcernsView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct ResourcesNoiseConcernsView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Noise Concerns")
                .multilineTextAlignment(.center)
            
            VStack {
                ResourcesAdviceText(adviceText: "Make an effort to resolve the problem with your neighbours directly. If this is unsuccessful, contact your local council.",
                                    secondaryText: "People can often be unaware of the noise they are making - simply knocking on their door and having a conversation with them, or passing a polite note with your contact details through their letterbox can go a long way to helping them gain an understanding of the difficulties their noise levels can cause. Try to avoid being rude or impolite - this may result in them increasing their noise levels out of resentment.\n\nIf you have made contact several times and the propblem persists, consider contacting your local council to issue them an official warning. The council will not intervene if the noise is reasonable (e.g. a baby crying, or most sound between 7am - 11pm), so ensure your complaint is something they can get involved with. They may also advise a Mediation Service - these are free, impartial services that can intervene and help you out.",
                                    bottomPadding: 18
                )
            }
            .frame(width: 340, height: 560, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "The penalty for noise concerns is usually a fine. Fines disproportionately affect poorer people, and so are an unfair punishment - especially when there are alternative routes you can take for dealing with the situation. Bringing the police into your community can also be dangerous for certain people, particulary people from ethnic minority backgrounds and people with disabilities.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesNoiseConcernsView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesNoiseConcernsView()
    }
}

//
//  ResourcesSexualAssault.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct ResourcesSexualAssaultView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Sexual Assault")
                .multilineTextAlignment(.center)
            
            VStack {
                
                ResourcesAdviceText(adviceText: "Contact your GP or voluntary orginsation.",
                                    secondaryText: "You may be risk of pregnancy or contracting a sexually transmitted infection. Your GP can advise you on seeking support for this. Try to avoid washing your clothes after an assault - they may be used as forensic evidence if needed.\n\nFind your nearest sexual assault referral centre (SARC). They will provide medical help and support. You will not have to have a forensic medical examination if you do not want to.\n\nTo support someone who has been sexually assaulted, ensure you do not blame them - it is never the fault of the person who has been abused. Listen to them, but do not ask for details, or ask why they didn't stop it. Offer practical support, such as booking and attending appointments with them.",
                                    bottomPadding: 18
                )
                
                Group {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(spacing: 0) {
                            Text("• ")
                            Link("Women's Aid", destination: URL(string: "https://chat.womensaid.org.uk/")!)
                            Spacer()
                        }
                        
                        HStack(spacing: 0) {
                            Text("• ")
                            Link("The Survior's Trust", destination: URL(string: "https://www.thesurvivorstrust.org/")!)
                            Spacer()
                        }
                        
                        HStack(spacing: 0) {
                            Text("• ")
                            Link("Victim Support", destination: URL(string: "https://www.victimsupport.org.uk/help-and-support/get-help/")!)
                            Spacer()
                        }
                        
                        Text("• For male, trans, and non-binary victims")
                            .font(.system(size: 16, weight: .medium, design: .default))
                        
                        HStack(spacing: 0) {
                            Text("  specifically: ")
                                .font(.system(size: 16, weight: .medium, design: .default))
                            Link("Survivors UK", destination: URL(string: "https://www.survivorsuk.org/")!)
                            Spacer()
                        }
                        
                        Text("• 24 hour freephone, run by Refuge: ")
                            .font(.system(size: 16, weight: .medium, design: .default))
                        Link("  0808 2000 247", destination: URL(string: "tel://08082000247")!)
                        
                    }
                    .padding(.horizontal, 12)
                }
            }
            .frame(width: 340, height: 660, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "The police do not have the specific training that the resources provided do. They may be insenesitive, blaming, ask invasive questions, or show a lack of belief. Just 1.5% of reported rape cases in the UK resulted in an arrest in 2018. Being questioned by the police and in court can be a very daunting, harmful experience. Working with prevention organisations may result in more justice than going to the police.")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesSexualAssault_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesSexualAssaultView()
    }
}

//
//  ResourcesShopliftingView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 24/04/2021.
//

import SwiftUI

struct ResourcesShopliftingView: View {
    var body: some View {
        ScrollView {
            SubheadingText(titleText: "Shoplifting")
                .multilineTextAlignment(.center)
            
            VStack {
                ResourcesAdviceText(adviceText: "If you see someone shoplifting, understand the situation they must be in to result in them doing that. If you can, offer to pay for what they are taking.",
                                    secondaryText: "People risk shoplifting when they are in desperate need of food or other products. It is important to understand the situation they are in that results in them needing to shoplift (likely extreme financial hardship).\n\nIf you are the position to do so, offer to purchase the items for them, to avoid them getting into trouble. The money lost from wage theft by large corporations (e.g. by failing to pay overtime, violating minimum-wage laws, not paying annual leave ketc) outweighs the money lost by shoplifting in the UK.",
                                    bottomPadding: 18
                )
            }
            .frame(width: 340, height: 410, alignment: .topLeading)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color("PrimaryColour"), lineWidth: 2)
            )
            
            ResourcesPoliceContact(bodyText: "Involving the police is only likely to lead to the person shoplifting receiving a fine (or worse, prison sentence). The financial burden of both of these outcomes is likely to result in the convicted person having to shoplift again in the future, and the cycle continues. A more effective way to reduce shoplifting isn't to punish those who do it by fining them, but to reduce the factors that lead to it in the first place (e.g. increased universal basic income).")
                .frame(width: 340, alignment: .leading)
                .padding(.horizontal, 6)
            
            Spacer()
        }
    }
}

struct ResourcesShopliftingView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesShopliftingView()
    }
}

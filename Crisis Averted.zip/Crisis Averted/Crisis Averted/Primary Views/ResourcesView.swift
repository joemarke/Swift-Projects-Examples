//
//  ResourcesView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 30/03/2021.
//

import SwiftUI

struct ResourcesView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                TitleText(titleText: "Resources")
                Text("Involving the police in your community can be dangerous, particularly for people from minority ethnic backgrounds, and people with disabilities. Use the resources listed to find appropriate help for those in need, that does not involve the police.")
                    .font(.system(size: 16, weight: .medium, design: .default))
                    .padding(.horizontal, 14)
                    .foregroundColor(Color("TextGrey"))
                
                HStack {
                    SubheadingText(titleText: "Urgent help")
                    Spacer()
                }
                
                Group {
                    NavigationLink(destination: ResourcesAbuseAtHomeView()) {
                        ResourcesButton(buttonText: "Abuse at home")
                    }
                    NavigationLink(destination: ResourcesAddictionView()) {
                        ResourcesButton(buttonText: "Addiction")
                    }
                    NavigationLink(destination: ResourcesHelpingTheHomelessView()) {
                        ResourcesButton(buttonText: "Helping the homeless")
                    }
                    NavigationLink(destination: ResourcesMentalHealthCrisisView()) {
                        ResourcesButton(buttonText: "Mental health crisis")
                    }
                    NavigationLink(destination: ResourcesSexualAssaultView()) {
                        ResourcesButton(buttonText: "Sexual assault")
                    }
                }
                
                HStack {
                    SubheadingText(titleText: "Common issues")
                    Spacer()
                }
                
                Group {
                    NavigationLink(destination: ResourcesLostPetView()) {
                        ResourcesButton(buttonText: "Lost pet")
                    }
                    NavigationLink(destination: ResourcesNoiseConcernsView()) {
                        ResourcesButton(buttonText: "Noise concerns")
                    }
                    NavigationLink(destination: ResourcesAbandonedVehicleView()) {
                        ResourcesButton(buttonText: "Abandoned or poorly\nparked vehicle")
                    }
                    NavigationLink(destination: ResourcesShopliftingView()) {
                        ResourcesButton(buttonText: "Shoplifting")
                    }
                }
                Text("")
                    .padding(.bottom, 12)
            }
            .navigationTitle("Crisis Averted")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading){
                    NavigationLink(destination: SettingsView()) {
                        Image(systemName: "gear")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: InformationView()) {
                        Image(systemName: "info.circle")
                    }
                }
            }
        }
    }
}

struct ResourcesView_Previews: PreviewProvider {
    static var previews: some View {
        ResourcesView()
    }
}

struct ResourcesButton: View {
    var buttonText: String
    var body: some View {
        ButtonTextOnly(buttonText: buttonText,
                       buttonWidth: 280,
                       buttonHeight: 54,
                       buttonPadding: 2)
    }
}

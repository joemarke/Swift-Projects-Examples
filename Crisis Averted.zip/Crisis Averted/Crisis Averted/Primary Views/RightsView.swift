//
//  RecordView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 30/03/2021.
//

import SwiftUI

struct RightsView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                TitleText(titleText: "What are my rights?")
                
                Link(destination: URL(string: "https://www.policeconduct.gov.uk/complaints-reviews-and-appeals/make-complaint")!) {
                    ButtonTextOnly(buttonText: "Report inappropriate police action", buttonWidth: 340, buttonHeight: 48, buttonPadding: 0)
                }
                
                Text("If you believe a police officer has acted inappropriately, you can report their actions to the Independent Office for Police Conduct for review.")
                    .font(.system(size: 16, weight: .medium, design: .default))
                    .italic()
                    .padding(.horizontal, 24)
                    .padding(.vertical, 2)
                    .foregroundColor(Color("TextGrey"))
                
                Group {
                    QuestionText(titleText: "Can I film the police?",
                                 bodyText: "Yes. Any member of the public can film a police offer without needing their permission. The police have no power to stop you from doing so, unless they believe the video will be used for the purposes of terrorism.")
                    
                    QuestionText(titleText: "Are the police allowed to enter my home?",
                                 bodyText: "No, unless they have a warrant, or if any of the following are true: you have given them permission; they are in close pursuit of someone they believe has committed a crime; to sort out a disturbance; if they hear cries of help.")
                    
                    QuestionText(titleText: "What information should I give to the police if they stop me?",
                                 bodyText: "If a police officer stops you for questioning, they may ask you for your name, what you are doing and where you are going. You do not need to answer any questions. Doing so will not be used as a reason to search or arrest you.")
                    
                    QuestionText(titleText: "What should I do if I get arrested?",
                                 bodyText: "The police must identify themselves, and explain what crime you have committed before they arres you. You then have the right to get free legal advice, as well as the right to tell someone where you are, and seek medical help if needed. You can be kept in custody for up to 24 hours; after that, they must either release you or charge you with a crime (so long as they haven't applied for a 36 - 96 hour extension, normally only done in very serious crimes).\n\nThe police have the right to take your photograph, as well as fingerprints and DNA test without your permission.")
                    
                    QuestionText(titleText: "Do the police have a right to stop and search me?",
                                 bodyText: "The police can only stop and search you if they have reasonable grounds to suspect you are carrying drugs, a weapon, stolen property, or something that can be used to commit a crime. They can also search you if you're in a specific location if a senior officer has approved it. They must tell you their name and station, what they expect to find, and why they want to search you. You have a right to get a record of the search.\n\nThey can ask you to remove your jacket, coat or gloves - if they require the removal of any other clothes, they must take you out of public view, and the officer must be the same sex as you. Being searched does not mean you are being arrested.")
                    
                    QuestionText(titleText: "What should I do if I get pulled over?",
                                 bodyText: "You should slow down and pull over when it is safe to do so. The police can pull you over for any reason. They can ask for your driving license, insurance certificate, and MOT certificate. You should stay inside your car, and may be required to take a breathalyzer test - refusal can lead to your arrest.")
                    
                    Text("")
                        .padding(.bottom, 12)
                }
                
            }
            .navigationTitle("Crisis Averted")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading){
                    NavigationLink(destination: SettingsView()) {
                        Image(systemName: "gear")
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing){
                    NavigationLink(destination: InformationView()) {
                        Image(systemName: "info.circle")
                    }
                }
            }
        }
    }
}

struct RecordView_Previews: PreviewProvider {
    static var previews: some View {
        RightsView()
    }
}


struct QuestionText: View {
    
    var titleText: String
    var bodyText: String
    
    var body: some View {
        Group {
            HStack {
                SubheadingText(titleText: titleText)
                Spacer()
            }
            Text(bodyText)
                .font(.system(size: 16, weight: .medium, design: .default))
                .padding(.horizontal, 24)
                .foregroundColor(Color("TextGrey"))
        }
    }
}

//
//  ButtonTextAndImage.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct ButtonTextAndImage: View {
    
    var buttonImage: String
    var buttonText: String
    var buttonWidth: CGFloat?
    var buttonHeight: CGFloat?
    
    
    var body: some View {
        HStack {
            Image(systemName: buttonImage)
                .font(.system(size: 32))
            Text(buttonText)
        }
        .frame(width: buttonWidth, height: buttonHeight)
        .font(.system(size: 18, weight: .bold, design: .default))
        .foregroundColor(.white)
        .background(Color("PrimaryColour"))
        .cornerRadius(8)
    }
}

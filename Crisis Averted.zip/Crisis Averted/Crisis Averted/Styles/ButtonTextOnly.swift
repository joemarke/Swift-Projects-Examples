//
//  ButtonTextOnly.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct ButtonTextOnly: View {
    
    var buttonText: String
    var buttonWidth: CGFloat?
    var buttonHeight: CGFloat?
    var buttonPadding: CGFloat?
    
    
    var body: some View {
        Text(buttonText)
            .frame(width: buttonWidth, height: buttonHeight)
            .font(.system(size: 18, weight: .bold, design: .default))
            .multilineTextAlignment(.center)
            .foregroundColor(.white)
            .background(Color("PrimaryColour"))
            .cornerRadius(8)
            .padding(.vertical, buttonPadding)
    }
}

//
//  ResourcesAdviceText.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct ResourcesAdviceText: View {
    
    var adviceText: String
    var secondaryText: String
    var bottomPadding: CGFloat?
    
    var body: some View {
        HStack {
            Text("Advice")
                .font(.system(size: 20, weight: .bold, design: .default))
                .foregroundColor(Color("PrimaryColour"))
                .padding(.horizontal, 12)
                .padding(.top, 10)
                .padding(.bottom, 1)
            Spacer()
        }
        HStack {
            Text(adviceText)
                .font(.system(size: 16, weight: .medium, design: .default))
                .padding(.horizontal, 12)
            Spacer()
        }
        HStack {
            Text(secondaryText)
                .font(.system(size: 16, weight: .light, design: .default))
                .padding(.horizontal, 12)
                .padding(.bottom, bottomPadding)
            Spacer()
        }
    }
}

//
//  ResourcesPoliceContact.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct ResourcesPoliceContact: View {
    
    var bodyText: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Why shouldn't I contact the police?")
                .font(.system(size: 22, weight: .bold, design: .default))
                .padding(.vertical, 12)
            Text(bodyText)
                .font(.system(size: 16, weight: .light, design: .default))
        }
        .frame(width: 340, alignment: .leading)
        .padding(.top, 24)
        .padding(.horizontal, 6)
    }
}

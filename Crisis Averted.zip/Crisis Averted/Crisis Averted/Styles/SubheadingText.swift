//
//  SubheadingText.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct SubheadingText: View {
    var titleText: String
    
    var body: some View {
        Text(titleText)
            .font(.system(size: 24, weight: .bold, design: .default))
            .padding(.horizontal, 24)
            .padding(.vertical, 12)
    }
}

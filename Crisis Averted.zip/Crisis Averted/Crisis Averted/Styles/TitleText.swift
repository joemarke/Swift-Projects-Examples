//
//  TitleText.swift
//  Crisis Averted
//
//  Created by Joe Marke on 23/04/2021.
//

import SwiftUI

struct TitleText: View {
    var titleText: String
    
    var body: some View {
        Text(titleText)
            .font(.system(size: 32, weight: .bold, design: .default))
            .multilineTextAlignment(.center)
            .padding(24.0)
    }
}

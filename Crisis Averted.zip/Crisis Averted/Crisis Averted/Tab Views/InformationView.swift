//
//  InformationView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 30/03/2021.
//

import SwiftUI

struct InformationView: View {
    var body: some View {
        ScrollView {
            TitleText(titleText: "Information")
            
            Group {
                HStack {
                    SubheadingText(titleText: "Why shouldn't I call the police?")
                    Spacer()
                }
                InformationText(infoText: "Calling the police can escalates situations, putting people at risk and leading to violence. Anytime you seek help from the police, you’re inviting them into your community and putting people who may already be vulnerable into dangerous situations. Sometimes people feel that calling the police is the only way to deal with problems. But we can build trusted networks of mutual aid that allow us to better handle conflicts ourselves and move toward forms of transformative justice, while keeping police away from our neighbourhoods.")
            }
            
            Group {
                HStack {
                    SubheadingText(titleText: "What does this app do?")
                    Spacer()
                }
                InformationText(infoText: "Crisis Averted informs you of how to appropriately respond in a crisis, as well as telling you what your rights are when having an interaction with the police. It also locates a variety of useful community help centres, that provide a good communal service.")
            }
            
            Group {
                HStack {
                    SubheadingText(titleText: "What can I do to help my community?")
                    Spacer()
                }
                InformationText(infoText: "Check out the 'Help Out' section to find local help centres that you can offer your help to, via volunteering or donations. Developing these centres builds up the infrastructure of your community, which can decrease crime rates, reducing the need for police interference.")
            }
            
            Group {
                HStack {
                    SubheadingText(titleText: "Are there any circumstances I should call the police?")
                    Spacer()
                }
                InformationText(infoText: "Very extreme incidents, such as murder, are currently best dealt with by the police. The purpose of the 'Resources' section is to educate you on the suitable alternatives available that are better suited to dealing with a crisis than involving the police.")
            }
            
            VStack(spacing: 0) {
                HStack {
                    SubheadingText(titleText: "Is the 'Resources' section an exhaustive list?") 
                    Spacer()
                }
                InformationText(infoText: "No. The section displays the most common reasons people go to the police. It should get you into the mindset of dealing with a crisis in a more community-oriented way, rather than instinctively calling the police. This style of thinking can be used for any crises you may have that are not listed in this section. There are also some situations where there currently isn't a more appropriate solution than calling the police.\n\nIf there are any examples of crises that you wish had a better solution than calling the police, you can contact your local MP, and attempt to organise an appropriate crisis avertion team. If any solution has been missed on this app, you can")
                HStack {
                    Link("contact us.", destination: URL(string: "mailto:joe.ik.marke@gmail.com")!)
                        .padding(.horizontal, 24)
                        .padding(.bottom, 24)
                    Spacer()
                }
            }
        }
    }
}

struct InformationView_Previews: PreviewProvider {
    static var previews: some View {
        InformationView()
    }
}

struct InformationText: View {
    var infoText: String
    var body: some View {
        HStack {
            Text(infoText)
                .font(.system(size: 16, weight: .light, design: .default))
                .padding(.horizontal, 24)
            Spacer()
        }
    }
}

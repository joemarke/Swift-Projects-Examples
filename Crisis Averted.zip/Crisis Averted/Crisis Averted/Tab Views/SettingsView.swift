//
//  SettingsView.swift
//  Crisis Averted
//
//  Created by Joe Marke on 30/03/2021.
//

import SwiftUI

struct SettingsView: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    var body: some View {
        VStack {
            TitleText(titleText: "Settings")
           
            Toggle(isOn: $isDarkMode) {
                Text("Dark mode")
            }
            .padding(.horizontal, 24)
           
            Divider()
            
            Spacer()
        } 
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
